<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="couponwheel_notice"></div>
<script>
window.addEventListener('load',function() { window.couponwheel_notice.reload(); });
</script>